import { Component, OnInit } from '@angular/core';
import { Router } from  '@angular/router';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['../menu.page.scss','./aboutus.component.scss'],
})
export class AboutusComponent {

  constructor() { }


}
