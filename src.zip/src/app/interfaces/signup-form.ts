export interface SignupForm {
    username: string,
    email: string,
    password: string
}
