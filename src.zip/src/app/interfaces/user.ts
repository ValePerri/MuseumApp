export interface User {
  username: string,
  auth?: string,
  password: string
}
