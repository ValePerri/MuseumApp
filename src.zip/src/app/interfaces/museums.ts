import { Time } from '@angular/common';

export interface museums {
    idmuseum:number, 
    name: string, 
    style: string
}
