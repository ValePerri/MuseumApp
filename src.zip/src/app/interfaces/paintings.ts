export interface Paintings {
    qrcode: string,
    title:  string,
    description: string, 
    author: string,
    year: Int16Array, 
    image: string
}
