export interface feedbackForm {
    userN: string,
    qrid: string,
    rate: number,
}
